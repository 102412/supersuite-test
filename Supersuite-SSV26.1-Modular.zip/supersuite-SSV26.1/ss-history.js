/* ═══════════════════════════════════════════════════════════════════
   SUPERSUITE — ss-history.js
   SSV26.1 · Undo / Redo history stack
   ─────────────────────────────────────────────────────────────────
   Max 50 snapshots. Last-write-wins. Snapshots are JSON strings
   of blocks + globalStyles + customCSS + blockIdCounter.
═══════════════════════════════════════════════════════════════════ */

'use strict';

const History = {
  _stack:    [],
  _cursor:   -1,
  _maxSize:  50,
  _skipNext: false,

  push() {
    if (this._skipNext) { this._skipNext = false; return; }
    if (this._cursor < this._stack.length - 1) {
      this._stack.splice(this._cursor + 1);
    }
    const snapshot = JSON.stringify({
      blocks:         State.blocks,
      globalStyles:   State.globalStyles,
      customCSS:      State.customCSS,
      blockIdCounter: State.blockIdCounter,
    });
    if (this._stack.length && this._stack[this._cursor] === snapshot) return;
    this._stack.push(snapshot);
    if (this._stack.length > this._maxSize) this._stack.shift();
    this._cursor = this._stack.length - 1;
    this._updateArrows();
  },

  back() {
    if (this._cursor <= 0) return;
    this._cursor--;
    this._apply();
    showToast('↩ Undo', 'Step ' + this._cursor + ' of ' + (this._stack.length - 1), 'info');
  },

  forward() {
    if (this._cursor >= this._stack.length - 1) return;
    this._cursor++;
    this._apply();
    showToast('↪ Redo', 'Step ' + this._cursor + ' of ' + (this._stack.length - 1), 'info');
  },

  _apply() {
    try {
      const snap = JSON.parse(this._stack[this._cursor]);
      this._skipNext       = true;
      State.blocks         = snap.blocks || [];
      State.globalStyles   = { ...State.globalStyles, ...snap.globalStyles };
      State.customCSS      = snap.customCSS || '';
      State.blockIdCounter = snap.blockIdCounter || 1;
      refreshPreview();
      updateLayers();
      this._updateArrows();
    } catch(e) { console.error('[History] Apply error:', e); }
  },

  _updateArrows() {
    const back = document.getElementById('hist-back-btn');
    const fwd  = document.getElementById('hist-fwd-btn');
    if (back) back.disabled = this._cursor <= 0;
    if (fwd)  fwd.disabled  = this._cursor >= this._stack.length - 1;
  },
};

function historyBack()    { History.back(); }
function historyForward() { History.forward(); }
