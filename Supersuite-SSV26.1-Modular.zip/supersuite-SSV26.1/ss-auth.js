/* ═══════════════════════════════════════════════════════════════════
   SUPERSUITE — ss-auth.js
   SSV26.1 · Access codes · Tier limits · Usage tracking · Email auth
   ─────────────────────────────────────────────────────────────────
   GUMROAD PAYMENT MODEL:
     Landing page → Gumroad Buy → Unique code generated → ZIP download
     → Code works in builder until first export
     → Export clicked → Code burns forever (server-side when backend added)

   BACKEND UPGRADE (when ready):
     1. Set SS_CONFIG.backendEnabled = true
     2. Set SS_CONFIG.backendURL = 'https://your-railway-url.app'
     3. Auth.verify() and GumroadAuth.burnCode() will auto-switch to server calls
     4. No other changes needed
═══════════════════════════════════════════════════════════════════ */

'use strict';

/* ─────────────────────────────────────────────────────────────────
   BACKEND CONFIG — flip the switch when your server is ready
───────────────────────────────────────────────────────────────── */
const SS_CONFIG = {
  backendEnabled: false,                      // ← set true when server is live
  backendURL:     'https://YOUR-RAILWAY-URL', // ← paste your Railway URL here
};

/* ─────────────────────────────────────────────────────────────────
   PASSWORD DATABASE — manage access codes here
   Each entry: 'CODE': { note: 'description' }
   Codes are matched case-insensitively.

   BACKEND UPGRADE: This entire object moves server-side.
   When backendEnabled = true, Auth.verify() ignores this object
   and calls your /validate-code endpoint instead.
───────────────────────────────────────────────────────────────── */
const SS_PASSWORD_DB = {

  // ── FREE / TRIAL ───────────────────────────────────────────────
  free: {
    'SS26':       { note: 'Default public demo code' },
    'TRYME':      { note: 'General trial invite' },
    'FREETRIAL':  { note: 'Marketing campaign — batch A' },
    // ↓ Add free codes below this line
  },

  // ── BASIC ──────────────────────────────────────────────────────
  basic: {
    'SSBASIC':    { note: 'Default basic test code' },
    'BASIC2026':  { note: 'Basic launch cohort' },
    // ↓ Add basic codes below this line
  },

  // ── PRO ────────────────────────────────────────────────────────
  pro: {
    'SSPRO':        { note: 'Default pro test code' },
    'PROLAUNCH':    { note: 'Pro early adopter — batch A' },
    'BUILDFAST':    { note: 'Pro early adopter — batch B' },
    // ↓ Add pro codes below this line
  },

  // ── AGENCY ─────────────────────────────────────────────────────
  agency: {
    'SSAGENCY':     { note: 'Default agency test code' },
    'AGENCYLAUNCH': { note: 'Agency founding client — batch A' },
    'ROASRYE':      { note: 'Personal code' },
    'SSSTUDIO':     { note: 'Studio Agent — standalone access' },
    'POPPY':        { note: 'Agency · Poppy access' },
    '26.1.1':       { note: 'Agency · Build 26.1.1' },
    '26.1.2':       { note: 'Agency · Build 26.1.2' },
    '26.1.3':       { note: 'Agency · Build 26.1.3' },
    // ↓ Add agency codes below this line
  },

};

/* ─────────────────────────────────────────────────────────────────
   AUTH — code verification and tier resolution
───────────────────────────────────────────────────────────────── */
const Auth = {
  version: 'SSV26.1',

  tiers: {
    free:   { label: 'Free Trial', sitesPerWeek: 1,   sitesPerDay: 0,   sessionMinutes: 30,   weekly: true  },
    basic:  { label: 'Basic',      sitesPerWeek: 0,   sitesPerDay: 1,   sessionMinutes: 60,   weekly: false },
    pro:    { label: 'Pro',        sitesPerWeek: 0,   sitesPerDay: 3,   sessionMinutes: 180,  weekly: false },
    agency: { label: 'Agency',     sitesPerWeek: 0,   sitesPerDay: 999, sessionMinutes: 9999, weekly: false },
  },

  /**
   * verify(code) → { ok, tier, label, note, error }
   *
   * FRONTEND MODE (current): checks SS_PASSWORD_DB locally.
   * BACKEND MODE (future):   calls /validate-code on your server.
   *
   * The rest of the app only reads ok/tier/label — no other changes needed
   * when switching to backend mode.
   */
  verify(code) {
    const normalised = code.trim().toUpperCase();
    if (!normalised) return { ok: false, error: 'Please enter an access code.' };

    // ── Frontend local check (no backend yet) ──────────────────
    for (const [tierKey, entries] of Object.entries(SS_PASSWORD_DB)) {
      for (const [dbCode, meta] of Object.entries(entries)) {
        if (dbCode.toUpperCase() === normalised) {
          const tierCfg = this.tiers[tierKey] || this.tiers.free;
          return { ok: true, tier: tierKey, label: tierCfg.label, note: meta.note || '' };
        }
      }
    }

    return { ok: false, error: 'Invalid access code. Check your purchase email or see plans below.' };
  },

  getTierConfig(tier) {
    return this.tiers[tier] || this.tiers.free;
  },

  /** Dev utility — call Auth.listCodes() in browser console to audit all codes */
  listCodes() {
    const out = [];
    for (const [tier, entries] of Object.entries(SS_PASSWORD_DB)) {
      for (const [code, meta] of Object.entries(entries)) {
        out.push({ code, tier, label: this.tiers[tier]?.label || tier, note: meta.note });
      }
    }
    console.table(out);
    return out;
  },
};

/* ─────────────────────────────────────────────────────────────────
   GUMROAD AUTH — one-time export burn system
   ─────────────────────────────────────────────────────────────────
   HOW IT WORKS (frontend-only mode):
     • Code is stored in State.accessCode on login
     • On export: GumroadAuth.validateAndBurn() is called
     • Frontend-only: marks code as burned in localStorage (soft lock)
     • Backend mode: calls /validate-code then /burn-code on server (hard lock)

   BACKEND UPGRADE:
     Set SS_CONFIG.backendEnabled = true and SS_CONFIG.backendURL = your URL.
     Everything below auto-switches. No other changes needed.
───────────────────────────────────────────────────────────────── */
const GumroadAuth = {
  _burnedKey: 'ss_burned_codes_v1', // localStorage key for frontend-only burn tracking

  /**
   * validateAndBurn(code) → Promise<{ ok, error }>
   *
   * Call this at the START of exportSite().
   * Returns { ok: true } if export should proceed.
   * Returns { ok: false, error: '...' } if it should be blocked.
   *
   * FRONTEND MODE: checks localStorage for already-burned codes.
   * BACKEND MODE:  calls /validate-code then /burn-code on server.
   */
  async validateAndBurn(code) {
    if (!code) return { ok: false, error: 'No access code found. Please log in again.' };

    // ── BACKEND MODE (uncomment when server is ready) ──────────
    // if (SS_CONFIG.backendEnabled) {
    //   return await this._serverValidateAndBurn(code);
    // }

    // ── FRONTEND MODE (current) ────────────────────────────────
    return this._localValidateAndBurn(code);
  },

  /** Frontend-only: use localStorage to track burned codes */
  _localValidateAndBurn(code) {
    const burned = this._getBurned();

    // Check if already burned
    if (burned.includes(code.toUpperCase())) {
      return { ok: false, error: 'This code has already been used to export a site.' };
    }

    // Burn it locally
    burned.push(code.toUpperCase());
    this._saveBurned(burned);

    return { ok: true };
  },

  /** BACKEND MODE — uncomment this when server is live */
  // async _serverValidateAndBurn(code) {
  //   try {
  //     const check = await fetch(SS_CONFIG.backendURL + '/validate-code', {
  //       method: 'POST',
  //       headers: { 'Content-Type': 'application/json' },
  //       body: JSON.stringify({ code }),
  //     }).then(r => r.json());
  //
  //     if (!check.ok) return { ok: false, error: check.error || 'Code invalid or already used.' };
  //
  //     // Burn the code server-side — point of no return
  //     await fetch(SS_CONFIG.backendURL + '/burn-code', {
  //       method: 'POST',
  //       headers: { 'Content-Type': 'application/json' },
  //       body: JSON.stringify({ code }),
  //     });
  //
  //     return { ok: true };
  //   } catch (e) {
  //     return { ok: false, error: 'Could not reach server. Check your connection and try again.' };
  //   }
  // },

  _getBurned() {
    try {
      const raw = localStorage.getItem(this._burnedKey);
      return raw ? JSON.parse(raw) : [];
    } catch(e) { return []; }
  },

  _saveBurned(arr) {
    try { localStorage.setItem(this._burnedKey, JSON.stringify(arr)); } catch(e) {}
  },

  /** Check if current code is already burned (without burning it) */
  isAlreadyBurned(code) {
    if (!code) return false;
    return this._getBurned().includes(code.toUpperCase());
  },
};

/* ─────────────────────────────────────────────────────────────────
   USAGE TRACKER — session time + export limits per tier
───────────────────────────────────────────────────────────────── */
const UsageTracker = {
  _storageKey:      'ss_usage_v261',
  _timerInterval:   null,
  _sessionStartMs:  null,

  _load() {
    try {
      const raw = localStorage.getItem(this._storageKey);
      if (raw) return JSON.parse(raw);
    } catch(e) {}
    return this._fresh();
  },

  _fresh() {
    const now = new Date();
    return {
      date:             now.toDateString(),
      week:             this._weekKey(now),
      sessionSeconds:   0,
      exportsToday:     0,
      exportsThisWeek:  0,
      tier:             'free',
    };
  },

  _weekKey(d) {
    const date = new Date(+d);
    date.setHours(0,0,0,0);
    date.setDate(date.getDate() + 4 - (date.getDay() || 7));
    const yearStart = new Date(date.getFullYear(),0,1);
    return date.getFullYear() + '-W' + Math.ceil((((date - yearStart) / 86400000) + 1) / 7);
  },

  _save(record) {
    try { localStorage.setItem(this._storageKey, JSON.stringify(record)); } catch(e) {}
  },

  init(tier) {
    const now = new Date();
    let record = this._load();

    if (record.date !== now.toDateString()) {
      record.date = now.toDateString();
      record.sessionSeconds = 0;
      record.exportsToday = 0;
    }

    const wk = this._weekKey(now);
    if (record.week !== wk) {
      record.week = wk;
      record.exportsThisWeek = 0;
    }

    record.tier = tier;
    this._save(record);
    this._sessionStartMs = Date.now();
    this._startTimer(record);
  },

  _startTimer(record) {
    if (this._timerInterval) clearInterval(this._timerInterval);
    let seconds = record.sessionSeconds;
    const cfg = Auth.getTierConfig(record.tier);
    const limitSec = cfg.sessionMinutes * 60;

    this._timerInterval = setInterval(() => {
      seconds++;
      if (seconds % 10 === 0) {
        const r = this._load();
        r.sessionSeconds = seconds;
        this._save(r);
      }
      this._updateTimerUI(seconds, limitSec);

      if (record.tier !== 'agency' && seconds >= limitSec) {
        clearInterval(this._timerInterval);
        this._showLimitModal('session');
      }
    }, 1000);
  },

  _updateTimerUI(seconds, limitSec) {
    const el = document.getElementById('nav-timer');
    if (!el) return;
    const mm = String(Math.floor(seconds / 60)).padStart(2, '0');
    const ss = String(seconds % 60).padStart(2, '0');
    el.textContent = mm + ':' + ss;
    const remaining = limitSec - seconds;
    el.classList.toggle('warning', remaining < 300 && remaining > 0);
    el.classList.toggle('danger',  remaining < 60  && remaining > 0);
  },

  canExport() {
    const r = this._load();
    const cfg = Auth.getTierConfig(r.tier);
    if (r.tier === 'agency') return true;
    if (cfg.weekly) return r.exportsThisWeek < cfg.sitesPerWeek;
    return r.exportsToday < cfg.sitesPerDay;
  },

  recordExport() {
    const r = this._load();
    r.exportsToday++;
    r.exportsThisWeek++;
    this._save(r);
  },

  _showLimitModal(type) {
    const r = this._load();
    const cfg = Auth.getTierConfig(r.tier);
    const titleEl = document.getElementById('ulm-title');
    const bodyEl  = document.getElementById('ulm-body');
    const badgeEl = document.getElementById('ulm-tier-badge');

    if (titleEl) titleEl.textContent = type === 'session'
      ? `Session limit reached (${cfg.sessionMinutes} min)`
      : `Export limit reached`;

    if (bodyEl) bodyEl.textContent = type === 'session'
      ? `Your ${cfg.label} plan allows ${cfg.sessionMinutes} minutes per day. Come back tomorrow or upgrade.`
      : `Your ${cfg.label} plan allows ${cfg.weekly ? cfg.sitesPerWeek + ' site/week' : cfg.sitesPerDay + ' site(s)/day'}. Upgrade to continue.`;

    if (badgeEl) {
      badgeEl.textContent = cfg.label;
      badgeEl.className = 'lmt-tier lmt-' + r.tier;
    }

    const modal = document.getElementById('usage-limit-modal');
    if (modal) modal.style.display = 'flex';
  },

  showExportLimitModal() { this._showLimitModal('export'); },
};

/* ─────────────────────────────────────────────────────────────────
   EMAIL AUTH — local per-device email + password auth
   (Extracted from original script.js lines 7312–7510)
───────────────────────────────────────────────────────────────── */
const EmailAuth = {
  _storageKey: 'ss_email_accounts_v1',
  _sessionKey: 'ss_email_session_v1',
  mode: 'signin', // 'signin' | 'signup'

  _getAccounts() {
    try { return JSON.parse(localStorage.getItem(this._storageKey) || '{}'); } catch(e) { return {}; }
  },

  _saveAccounts(accounts) {
    try { localStorage.setItem(this._storageKey, JSON.stringify(accounts)); } catch(e) {}
  },

  _hash(str) {
    // Simple hash for local storage — NOT for production use
    let h = 0;
    for (let i = 0; i < str.length; i++) {
      h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
    }
    return h.toString(16);
  },

  setMode(mode) {
    this.mode = mode;
    const signInFields  = document.getElementById('email-signin-fields');
    const signUpFields  = document.getElementById('email-signup-fields');
    const submitBtn     = document.getElementById('email-submit-btn');
    const switchText    = document.getElementById('email-switch-text');

    if (signInFields)  signInFields.style.display  = mode === 'signin'  ? 'block' : 'none';
    if (signUpFields)  signUpFields.style.display   = mode === 'signup'  ? 'block' : 'none';
    if (submitBtn)     submitBtn.textContent         = mode === 'signin'  ? 'Sign In' : 'Create Account';
    if (switchText) {
      switchText.innerHTML = mode === 'signin'
        ? `Don't have an account? <a href="#" onclick="EmailAuth.setMode('signup');return false;">Sign Up</a>`
        : `Already have an account? <a href="#" onclick="EmailAuth.setMode('signin');return false;">Sign In</a>`;
    }
  },

  submit() {
    const email    = (document.getElementById('email-input')?.value   || '').trim().toLowerCase();
    const password = (document.getElementById('password-input')?.value || '').trim();
    const errorEl  = document.getElementById('email-error');

    if (!email || !password) {
      if (errorEl) errorEl.textContent = '❌ Please enter email and password.';
      return;
    }

    const accounts = this._getAccounts();

    if (this.mode === 'signup') {
      if (accounts[email]) {
        if (errorEl) errorEl.textContent = '❌ An account with that email already exists.';
        return;
      }
      // Default new email accounts to 'free' tier
      accounts[email] = { hash: this._hash(password), tier: 'free' };
      this._saveAccounts(accounts);
    }

    const account = accounts[email];
    if (!account || account.hash !== this._hash(password)) {
      if (errorEl) errorEl.textContent = '❌ Incorrect email or password.';
      return;
    }

    // Success — log in via same flow as code login
    const tier = account.tier || 'free';
    State.authenticated = true;
    State.userTier      = tier;
    State.accessCode    = 'EMAIL:' + email; // email accounts get a special code marker

    try { localStorage.setItem(this._sessionKey, JSON.stringify({ email, tier })); } catch(e) {}

    closeLoginModal();
    _launchBuilderApp(tier);
  },

  restoreSession() {
    try {
      const session = JSON.parse(localStorage.getItem(this._sessionKey) || 'null');
      if (session && session.email) {
        State.authenticated = true;
        State.userTier      = session.tier || 'free';
        State.accessCode    = 'EMAIL:' + session.email;
        return true;
      }
    } catch(e) {}
    return false;
  },

  signOut() {
    try { localStorage.removeItem(this._sessionKey); } catch(e) {}
  },
};
