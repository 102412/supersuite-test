/* ═══════════════════════════════════════════════════════════════════
   SUPERSUITE — ss-livesync.js
   SSV26.1 · Real-time collab sync
   ─────────────────────────────────────────────────────────────────
   Architecture:
     PUSH  → POST to relay (debounced 150ms) + BroadcastChannel + localStorage
     POLL  → GET relay every 400ms (cross-device)
   Works on any device, any browser. No third-party services required.
   Relay: https://ai-1a5e84f8.base44.app/functions/collabRelay
═══════════════════════════════════════════════════════════════════ */

'use strict';

const RELAY_URL = 'https://ai-1a5e84f8.base44.app/functions/collabRelay';

const LiveSync = {
  sessionCode:      null,
  isOwner:          false,
  channel:          null,
  _tabId:           Math.random().toString(36).slice(2, 10),
  _lastAppliedTs:   0,
  _syncInProgress:  false,
  _pushTimer:       null,
  _pollTimer:       null,
  _storageListener: null,

  init(code, isOwner) {
    this.sessionCode    = code;
    this.isOwner        = isOwner;
    this._lastAppliedTs = 0;
    this._syncInProgress = false;

    if (this.channel) { try { this.channel.close(); } catch(e) {} this.channel = null; }
    if (this._storageListener) {
      window.removeEventListener('storage', this._storageListener);
      this._storageListener = null;
    }

    try {
      this.channel = new BroadcastChannel('ss_collab_' + code);
      this.channel.onmessage = (ev) => this._applyPayload(ev.data, 'bc');
    } catch(e) {}

    this._storageListener = (e) => {
      if (e.key !== 'ss_collab_' + code || !e.newValue) return;
      try { this._applyPayload(JSON.parse(e.newValue), 'ls'); } catch(err) {}
    };
    window.addEventListener('storage', this._storageListener);

    this._startPolling();
    this._updateUI(true);
    this._pollNow();
  },

  destroy() {
    clearTimeout(this._pushTimer);
    clearInterval(this._pollTimer);
    this._pollTimer = null;
    if (this.channel) { try { this.channel.close(); } catch(e) {} this.channel = null; }
    if (this._storageListener) {
      window.removeEventListener('storage', this._storageListener);
      this._storageListener = null;
    }
    this.sessionCode = null;
    this._syncInProgress = false;
    this._updateUI(false);
  },

  notifyChange() {
    if (!this.sessionCode || this._syncInProgress) return;
    clearTimeout(this._pushTimer);
    this._pushTimer = setTimeout(() => this._push(), 150);
  },

  async _push() {
    if (!this.sessionCode || this._syncInProgress) return;
    const ts = Date.now();
    let stateJSON;
    try {
      stateJSON = JSON.stringify({
        blocks:          State.blocks,
        globalStyles:    State.globalStyles,
        currentTemplate: State.currentTemplate,
        customCSS:       State.customCSS,
        blockIdCounter:  State.blockIdCounter,
      });
    } catch(e) { return; }

    const payload = { type: 'STATE_UPDATE', ts, tabId: this._tabId, stateJSON };

    if (this.channel) { try { this.channel.postMessage(payload); } catch(e) {} }
    try { localStorage.setItem('ss_collab_' + this.sessionCode, JSON.stringify(payload)); } catch(e) {}

    this._flashSyncIndicator('syncing');
    try {
      const res = await fetch(RELAY_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'push', code: this.sessionCode, ts, tabId: this._tabId, state: stateJSON }),
      });
      this._flashSyncIndicator(res.ok ? 'synced' : 'error');
    } catch(e) {
      console.warn('[LiveSync] Relay push failed:', e.message);
      this._flashSyncIndicator('error');
    }
  },

  _startPolling() {
    clearInterval(this._pollTimer);
    this._pollTimer = setInterval(() => this._pollNow(), 400);
  },

  async _pollNow() {
    if (!this.sessionCode) return;
    try {
      const res = await fetch(RELAY_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'poll', code: this.sessionCode, since: this._lastAppliedTs, tabId: this._tabId }),
      });
      if (!res.ok) return;
      const data = await res.json();
      if (data.hasUpdate && data.state) {
        this._applyPayload({ type: 'STATE_UPDATE', ts: data.ts, tabId: data.tabId, stateJSON: data.state }, 'relay');
      }
    } catch(e) {}
  },

  _applyPayload(data, src) {
    if (!data || data.type !== 'STATE_UPDATE') return;
    if (data.tabId === this._tabId) return;
    if (data.ts <= this._lastAppliedTs) return;

    this._lastAppliedTs  = data.ts;
    this._syncInProgress = true;

    try {
      const s = typeof data.stateJSON === 'string' ? JSON.parse(data.stateJSON) : (data.state || {});
      if (s.blocks !== undefined)          State.blocks          = JSON.parse(JSON.stringify(s.blocks));
      if (s.globalStyles !== undefined)    State.globalStyles    = JSON.parse(JSON.stringify(s.globalStyles));
      if (s.currentTemplate !== undefined) State.currentTemplate = s.currentTemplate;
      if (s.customCSS !== undefined)       State.customCSS       = s.customCSS;
      if (s.blockIdCounter !== undefined && s.blockIdCounter > State.blockIdCounter)
        State.blockIdCounter = s.blockIdCounter;

      refreshPreview();
      updateLayers();
      this._flashSyncIndicator('synced');
    } catch(e) {
      console.error('[LiveSync] Apply failed:', e);
    } finally {
      this._syncInProgress = false;
    }
  },

  _flashSyncIndicator(state) {
    const bar    = document.querySelector('.collab-sync-bar');
    const status = document.getElementById('collab-sync-status');
    if (!bar || !status) return;
    clearTimeout(this._indicatorTimer);
    if (state === 'syncing') {
      bar.className  = 'collab-sync-bar syncing';
      status.textContent = 'Syncing…';
    } else if (state === 'error') {
      bar.className  = 'collab-sync-bar error';
      status.textContent = 'Sync error';
      this._indicatorTimer = setTimeout(() => {
        bar.className  = 'collab-sync-bar';
        status.textContent = '🟡 Local only';
      }, 3000);
    } else {
      bar.className  = 'collab-sync-bar';
      status.textContent = 'Synced ✓';
      this._indicatorTimer = setTimeout(() => {
        if (status) status.textContent = '🟢 Live';
      }, 2000);
    }
  },

  _updateUI(active) {
    const section = document.getElementById('collab-active-section');
    const info    = document.getElementById('collab-active-info');
    if (section) section.style.display = active ? 'block' : 'none';
    if (info && active) {
      info.textContent = (this.isOwner ? 'Owner' : 'Collaborator') + ' — Code: ' + this.sessionCode;
    }
  },
};

/* ─────────────────────────────────────────────────────────────────
   COLLAB UI FUNCTIONS
───────────────────────────────────────────────────────────────── */
function openCollabModal() {
  const modal = document.getElementById('collab-modal');
  if (modal) modal.style.display = 'flex';
  const codeEl = document.getElementById('collab-code-value');
  const stored = localStorage.getItem('ss_collab_code');
  if (stored && codeEl) codeEl.textContent = stored;
}

function closeCollabModal() {
  const modal = document.getElementById('collab-modal');
  if (modal) modal.style.display = 'none';
}

function generateCollabCode() {
  const code = Math.random().toString(36).substr(2,4).toUpperCase() +
               Math.random().toString(36).substr(2,4).toUpperCase();
  localStorage.setItem('ss_collab_code', code);
  const el = document.getElementById('collab-code-value');
  if (el) el.textContent = code;
  LiveSync.init(code, true);
  showToast('🔗 Code Generated', 'Share ' + code + ' with collaborators', 'success');
}

function copyCollabCode() {
  const code = document.getElementById('collab-code-value')?.textContent;
  if (!code || code === '—') { showToast('⚠️ No code', 'Generate a code first', 'warning'); return; }
  navigator.clipboard.writeText(code).catch(() => {});
  showToast('📋 Copied!', 'Invite code copied to clipboard', 'success');
}

function joinCollabSession() {
  const input  = document.getElementById('collab-join-input');
  const status = document.getElementById('collab-join-status');
  const code   = (input?.value || '').trim().toUpperCase();
  if (code.length < 6) {
    if (status) { status.textContent = '❌ Enter a valid code'; status.style.color = 'var(--ui-danger)'; }
    return;
  }
  LiveSync.init(code, false);
  showToast('🤝 Joined Session', 'Connected to project ' + code, 'success');
}

function leaveCollabSession() {
  LiveSync.destroy();
  localStorage.removeItem('ss_collab_code');
  showToast('👋 Left Session', 'You are now working locally', 'info');
}
