/* ═══════════════════════════════════════════════════════════════════
   SUPERSUITE — server.js (deploy to Railway when ready)
   ─────────────────────────────────────────────────────────────────
   SETUP:
     1. npm install express @supabase/supabase-js cors
     2. Create Supabase table:
          CREATE TABLE codes (
            code       TEXT PRIMARY KEY,
            tier       TEXT DEFAULT 'basic',
            used       BOOLEAN DEFAULT false,
            created_at TIMESTAMP DEFAULT now(),
            used_at    TIMESTAMP
          );
     3. Set env vars in Railway: SUPABASE_URL, SUPABASE_KEY
     4. Deploy → get live URL
     5. Paste URL into SS_CONFIG.backendURL in ss-auth.js
     6. Set SS_CONFIG.backendEnabled = true in ss-auth.js
═══════════════════════════════════════════════════════════════════ */

const express  = require('express');
const cors     = require('cors');
const { createClient } = require('@supabase/supabase-js');

const app      = express();
app.use(express.json());
app.use(cors());

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

// Validate code (called before export)
app.post('/validate-code', async (req, res) => {
  const { code } = req.body;
  if (!code) return res.json({ ok: false, error: 'No code provided.' });
  const { data } = await supabase.from('codes').select('*').eq('code', code.trim().toUpperCase()).single();
  if (!data)       return res.json({ ok: false, error: 'Invalid access code.' });
  if (data.used)   return res.json({ ok: false, error: 'This code has already been used to export a site.' });
  return res.json({ ok: true, tier: data.tier || 'basic' });
});

// Burn code (called after export files downloaded)
app.post('/burn-code', async (req, res) => {
  const { code } = req.body;
  if (!code) return res.json({ ok: false });
  await supabase.from('codes').update({ used: true, used_at: new Date().toISOString() }).eq('code', code.trim().toUpperCase());
  return res.json({ ok: true });
});

// Gumroad webhook — auto-creates code on every purchase
app.post('/gumroad-webhook', async (req, res) => {
  const { license_key, variants } = req.body;
  if (!license_key) return res.json({ ok: false });
  const tier = (variants?.Tier || 'basic').toLowerCase();
  await supabase.from('codes').insert({ code: license_key.trim().toUpperCase(), tier });
  return res.json({ ok: true });
});

app.listen(process.env.PORT || 3000, () => console.log('Supersuite server running'));
