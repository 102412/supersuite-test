SUPERSUITE SSV26.1 — MODULAR BUILD
====================================

QUICK START
──────────────────────────────────────────────────────────────────
  Open app.html in Chrome or Edge. That's it.
  All files must stay in the same folder.

ACCESS CODES
──────────────────────────────────────────────────────────────────
  Free:    SS26
  Basic:   SSBASIC
  Pro:     SSPRO
  Agency:  SSAGENCY · ROASRYE · SSSTUDIO

GUMROAD PAYMENT FLOW
──────────────────────────────────────────────────────────────────
  Landing page → Gumroad Buy → Unique code + ZIP download
  → Code works in builder until first export
  → Export clicked → Code burned forever (one-time use)

  CURRENT MODE: Frontend-only (codes burned in localStorage)
  BACKEND MODE: Set SS_CONFIG.backendEnabled = true in ss-auth.js
                Set SS_CONFIG.backendURL = your Railway server URL

MODULAR FILE STRUCTURE
──────────────────────────────────────────────────────────────────
  ss-state.js     — App state (single source of truth)
  ss-auth.js      — Access codes, tiers, Gumroad burn, UsageTracker
  ss-history.js   — Undo / Redo
  ss-livesync.js  — Real-time collab sync
  ss-export.js    — Export flow + burn check + build HTML/CSS/JS
  ss-ui.js        — Login, toast, panels, projects, BlockSelector
  ss-legacy.js    — Builder engine (blocks, templates, AI, studio)
  ss-launch.js    — Deploy / publish flow

  To add a feature: create ss-newfeature.js, add <script> to app.html

ELECTRON DESKTOP BUILD
──────────────────────────────────────────────────────────────────
  npm install
  npm run build:win    ← Windows .exe
  npm run build:mac    ← macOS .dmg
  npm run build:linux  ← Linux .AppImage

BACKEND (when ready)
──────────────────────────────────────────────────────────────────
  See server.js for Railway + Supabase setup.
  Takes ~1.5 hours to go live.

LAUNCH DATE: June 1, 2026
