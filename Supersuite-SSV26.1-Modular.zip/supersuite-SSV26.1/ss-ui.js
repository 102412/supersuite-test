/* ═══════════════════════════════════════════════════════════════════
   SUPERSUITE — ss-ui.js
   SSV26.1 · UI helpers · Login modal · Toast · Panels · Zoom · Tabs
   ─────────────────────────────────────────────────────────────────
   Contains:
     - checkPassword()         ← stores State.accessCode on login
     - openLoginModal / closeLoginModal
     - _launchBuilderApp()     ← shared launch sequence
     - showToast()
     - Panel / zoom / device / tab helpers
     - BlockSelector
     - Projects
     - switchLoginMode / switchEmailAuthMode
═══════════════════════════════════════════════════════════════════ */

'use strict';

/* ─────────────────────────────────────────────────────────────────
   LOGIN MODAL
───────────────────────────────────────────────────────────────── */
function openLoginModal(planHint) {
  document.getElementById('login-modal').style.display = 'flex';
  const input = document.getElementById('gate-input');
  let remembered = '';
  try { remembered = localStorage.getItem('ss_remember_code_v267') || ''; } catch(e) {}
  if (input) {
    input.value = remembered;
    input.focus();
    if (remembered) previewTierFromCode(remembered);
  }
  const remEl = document.getElementById('gate-remember');
  if (remEl) remEl.checked = !!remembered;
  document.getElementById('gate-error').textContent = '';
  if (!remembered) document.getElementById('login-tier-hint').style.display = 'none';
}

function closeLoginModal() {
  document.getElementById('login-modal').style.display = 'none';
}

/** Live-preview tier name as user types */
function previewTierFromCode(val) {
  const result = Auth.verify(val);
  const hint   = document.getElementById('login-tier-hint');
  if (!hint) return;
  if (val.length >= 4 && result.ok) {
    hint.style.display = 'flex';
    hint.textContent   = '✓ ' + result.label + ' plan detected';
  } else {
    hint.style.display = 'none';
  }
}

/** Switch between code tab and email tab in login modal */
function switchLoginMode(mode) {
  document.querySelectorAll('.login-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.login-pane').forEach(p => p.classList.remove('active'));
  const tab  = document.querySelector(`.login-tab[data-mode="${mode}"]`);
  const pane = document.getElementById('login-pane-' + mode);
  if (tab)  tab.classList.add('active');
  if (pane) pane.classList.add('active');
}

function switchEmailAuthMode(mode) { EmailAuth.setMode(mode); }

/* ─────────────────────────────────────────────────────────────────
   CHECK PASSWORD (code login)
   ─────────────────────────────────────────────────────────────────
   GUMROAD NOTE:
     State.accessCode is stored here and used by ss-export.js
     to validate + burn the code on first export.
───────────────────────────────────────────────────────────────── */
function checkPassword() {
  const input  = document.getElementById('gate-input');
  const error  = document.getElementById('gate-error');
  const val    = input.value.trim();
  const result = Auth.verify(val);

  if (result.ok) {
    State.authenticated = true;
    State.userTier      = result.tier;
    State.accessCode    = val.toUpperCase(); // ← stored for Gumroad burn on export

    // Remember-me persistence
    try {
      const remember = document.getElementById('gate-remember');
      if (remember && remember.checked) {
        localStorage.setItem('ss_remember_code_v267', val);
      } else {
        localStorage.removeItem('ss_remember_code_v267');
      }
    } catch(e) {}

    closeLoginModal();
    _launchBuilderApp(result.tier);
  } else {
    error.textContent    = '❌ ' + result.error;
    error.style.animation = 'none';
    requestAnimationFrame(() => { error.style.animation = 'shake 0.4s ease both'; });
    input.value = '';
    input.focus();
  }
}

/** Shared builder launch sequence — called by both code login and email login */
function _launchBuilderApp(tier) {
  const landing = document.getElementById('landing-page');
  if (landing) {
    landing.style.opacity    = '0';
    landing.style.transition = 'opacity 0.4s ease';
    setTimeout(() => { landing.style.display = 'none'; }, 400);
  }
  const app = document.getElementById('app');
  if (app) {
    setTimeout(() => { app.style.display = 'flex'; initApp(); }, 420);
  }
}

// Allow Enter key on login modal
document.addEventListener('keydown', function(e) {
  const loginModal = document.getElementById('login-modal');
  if (loginModal && loginModal.style.display !== 'none' && e.key === 'Enter') {
    checkPassword();
  }
});

/* ─────────────────────────────────────────────────────────────────
   INIT APP — called after successful login
───────────────────────────────────────────────────────────────── */
function initApp() {
  const tier      = State.userTier || 'free';
  const tierBadge = document.getElementById('nav-tier-badge');
  if (tierBadge) {
    const cfg          = Auth.getTierConfig(tier);
    tierBadge.textContent = cfg.label;
    tierBadge.className   = 'nav-tier-badge ' + tier;
  }

  UsageTracker.init(tier);
  BlockSelector.applyToSidebar();
  applyTemplate('glass');
  loadStarterDemo();

  try {
    State.currentDevice = 'desktop';
    if (typeof switchDevice === 'function') switchDevice('desktop');
  } catch(e) {}

  setTimeout(() => {
    if (Onboarding.isComplete()) {
      try { AIImprover.runOnLogin(); } catch(e) { console.warn('[AIImprover]', e); }
    } else {
      Onboarding.maybeShow();
    }
  }, 800);

  // Restore live collab session if one was active
  (function() {
    const savedCode = localStorage.getItem('ss_collab_code');
    if (savedCode) {
      setTimeout(() => {
        LiveSync.init(savedCode, true);
        setTimeout(() => LiveSync._pollNow(), 400);
      }, 500);
    }
  })();

  showToast('🎉 Welcome to Supersuite!', Auth.getTierConfig(tier).label + ' plan · ' + (Auth.version || 'SSV26.1'), 'success');
}

/* ─────────────────────────────────────────────────────────────────
   TOAST NOTIFICATIONS
───────────────────────────────────────────────────────────────── */
function showToast(title, message, type = 'info') {
  const container = document.getElementById('toast-container') || (() => {
    const c = document.createElement('div');
    c.id    = 'toast-container';
    c.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:99999;display:flex;flex-direction:column;gap:10px;';
    document.body.appendChild(c);
    return c;
  })();

  const colors = { success: '#22c55e', error: '#ef4444', warning: '#f59e0b', info: '#3b82f6' };
  const toast  = document.createElement('div');
  toast.style.cssText = `
    background:#1a1a2e;color:#fff;padding:14px 18px;border-radius:12px;
    border-left:4px solid ${colors[type] || colors.info};
    box-shadow:0 8px 32px rgba(0,0,0,0.35);
    min-width:260px;max-width:360px;
    animation:slideInRight 0.3s ease;
    font-family:'DM Sans',sans-serif;
  `;
  toast.innerHTML = `<div style="font-weight:600;font-size:14px;margin-bottom:3px;">${title}</div>
                     <div style="font-size:13px;opacity:0.8;">${message}</div>`;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.animation = 'slideOutRight 0.3s ease forwards';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

/* ─────────────────────────────────────────────────────────────────
   FAQ / NAV / UI HELPERS
───────────────────────────────────────────────────────────────── */
function toggleFaq(btn) {
  const answer = btn.nextElementSibling;
  const isOpen = answer.classList.contains('open');
  document.querySelectorAll('.lp-faq-a').forEach(a => a.classList.remove('open'));
  document.querySelectorAll('.lp-faq-q').forEach(b => b.classList.remove('open'));
  if (!isOpen) { answer.classList.add('open'); btn.classList.add('open'); }
}

function toggleLpNav() {
  const menu = document.getElementById('lp-nav-mobile');
  if (menu) menu.classList.toggle('open');
}

/* ─────────────────────────────────────────────────────────────────
   BLOCK SELECTOR — controls which block types appear in sidebar
───────────────────────────────────────────────────────────────── */
const BlockSelector = {
  _storageKey: 'ss_blockselector_v261',
  _allTypes:   ['nav','hero','leadform','testimonials','pricing','cta','features','gallery','footer'],

  getEnabled() {
    try {
      const raw = localStorage.getItem(this._storageKey);
      if (raw) return JSON.parse(raw);
    } catch(e) {}
    return [...this._allTypes];
  },

  save(enabledTypes) {
    try { localStorage.setItem(this._storageKey, JSON.stringify(enabledTypes)); } catch(e) {}
  },

  applyToSidebar() {
    const enabled = this.getEnabled();
    document.querySelectorAll('.block-card').forEach(card => {
      const match = card.getAttribute('onclick')?.match(/addBlock\('(\w+)'\)/);
      if (!match) return;
      card.style.display = enabled.includes(match[1]) ? '' : 'none';
    });
  },
};

function openBlockSelectorModal() {
  const enabled = BlockSelector.getEnabled();
  const list    = document.getElementById('block-selector-list');
  if (!list) return;

  const meta = {
    nav:          { icon: '🧭', label: 'Navigation',        desc: 'Site header & menu' },
    hero:         { icon: '⚡', label: 'Hero Section',      desc: 'Headline + CTA' },
    leadform:     { icon: '📋', label: 'Lead Form',         desc: 'Capture leads' },
    testimonials: { icon: '💬', label: 'Testimonials',      desc: 'Social proof cards' },
    pricing:      { icon: '💎', label: 'Pricing / Services',desc: 'Plans & tiers' },
    cta:          { icon: '🎯', label: 'CTA Section',       desc: 'Drive conversions' },
    features:     { icon: '✨', label: 'Features',          desc: 'Icon + text grid' },
    gallery:      { icon: '🖼️', label: 'Gallery',          desc: 'Image showcase' },
    footer:       { icon: '📌', label: 'Footer',            desc: 'Links & copyright' },
  };

  list.innerHTML = BlockSelector._allTypes.map(type => {
    const m  = meta[type] || { icon: '◻', label: type, desc: '' };
    const on = enabled.includes(type);
    return `
      <div class="bsl-item ${on ? 'enabled' : ''}" data-type="${type}" onclick="toggleBslItem(this)">
        <div class="bsl-check">${on ? '✓' : ''}</div>
        <span class="bsl-icon">${m.icon}</span>
        <div style="flex:1;">
          <div class="bsl-label">${m.label}</div>
          <div class="bsl-desc">${m.desc}</div>
        </div>
      </div>`;
  }).join('');

  document.getElementById('block-selector-modal').style.display = 'flex';
}

function toggleBslItem(el) {
  el.classList.toggle('enabled');
  const check = el.querySelector('.bsl-check');
  if (check) check.textContent = el.classList.contains('enabled') ? '✓' : '';
}

function closeBlockSelectorModal() {
  document.getElementById('block-selector-modal').style.display = 'none';
}

function saveBlockSelector() {
  const enabled = [];
  document.querySelectorAll('.bsl-item.enabled').forEach(el => enabled.push(el.dataset.type));
  BlockSelector.save(enabled);
  BlockSelector.applyToSidebar();
  closeBlockSelectorModal();
  showToast('✅ Block library updated', enabled.length + ' block types visible', 'success');
}

/* ─────────────────────────────────────────────────────────────────
   DEVICE / ZOOM / TABS / PANELS
───────────────────────────────────────────────────────────────── */
const DeviceWidths  = { desktop: '100%', tablet: '768px', mobile: '375px' };
const DeviceLabels  = { desktop: '🖥 Desktop', tablet: '📱 Tablet', mobile: '📱 Mobile' };

function switchDevice(device) {
  State.currentDevice = device;
  const frame = document.getElementById('preview-frame');
  if (frame) frame.style.width = DeviceWidths[device] || '100%';
  document.querySelectorAll('.device-btn').forEach(b => b.classList.remove('active'));
  const btn = document.querySelector(`.device-btn[onclick*="${device}"]`);
  if (btn) btn.classList.add('active');
}

function adjustZoom(delta) { State.zoomLevel = Math.max(25, Math.min(200, State.zoomLevel + delta)); applyZoom(); }
function resetZoom()        { State.zoomLevel = 100; applyZoom(); }
function applyZoom() {
  const frame = document.getElementById('preview-frame');
  if (frame) frame.style.transform = `scale(${State.zoomLevel / 100})`;
  const el = document.getElementById('zoom-level');
  if (el) el.textContent = State.zoomLevel + '%';
}

function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  const btn   = document.querySelector(`.tab-btn[onclick*="${tab}"]`);
  const panel = document.getElementById('tab-' + tab);
  if (btn)   btn.classList.add('active');
  if (panel) panel.classList.add('active');
}

function openRightPanel(title, content) {
  const panel = document.getElementById('right-panel');
  const titleEl   = document.getElementById('right-panel-title');
  const contentEl = document.getElementById('right-panel-content');
  if (titleEl)   titleEl.innerHTML   = title;
  if (contentEl) contentEl.innerHTML = content;
  if (panel) panel.classList.add('open');
}

function closeRightPanel() {
  const panel = document.getElementById('right-panel');
  if (panel) panel.classList.remove('open');
}

function openFullPreview() {
  const html  = buildPreviewHTML(false);
  const win   = window.open('', '_blank');
  if (win) { win.document.write(html); win.document.close(); }
}

function closeFullPreview() {
  // Full preview opens in a new tab — nothing to close from here
}

/* ─────────────────────────────────────────────────────────────────
   PROJECTS — save / load / delete named projects
───────────────────────────────────────────────────────────────── */
const Projects = {
  _storageKey: 'ss_projects_v261',

  list() {
    try { return JSON.parse(localStorage.getItem(this._storageKey) || '{}'); } catch(e) { return {}; }
  },

  save(name, data) {
    const all = this.list();
    all[name] = { ...data, savedAt: Date.now() };
    try { localStorage.setItem(this._storageKey, JSON.stringify(all)); } catch(e) {}
  },

  load(name) {
    return this.list()[name] || null;
  },

  delete(name) {
    const all = this.list();
    delete all[name];
    try { localStorage.setItem(this._storageKey, JSON.stringify(all)); } catch(e) {}
  },
};

function createNewProject() {
  SSPrompt.show('New Project', 'Enter a name for your project:', 'My Site', (name) => {
    if (!name) return;
    _createNewProjectInternal(name.trim());
  });
}

function _createNewProjectInternal(name) {
  State.blocks         = [];
  State.blockIdCounter = 1;
  State.customCSS      = '';
  applyTemplate(State.currentTemplate);
  loadStarterDemo();
  showToast('📁 New Project', '"' + name + '" created', 'success');
}

function saveCurrentProject() {
  SSPrompt.show('Save Project', 'Enter a name to save as:', 'My Site', (name) => {
    if (!name) return;
    Projects.save(name.trim(), {
      blocks:          JSON.parse(JSON.stringify(State.blocks)),
      globalStyles:    JSON.parse(JSON.stringify(State.globalStyles)),
      currentTemplate: State.currentTemplate,
      customCSS:       State.customCSS,
      blockIdCounter:  State.blockIdCounter,
    });
    showToast('💾 Saved', '"' + name + '" saved', 'success');
    renderProjectsList();
  });
}

function loadProject(name) {
  const data = Projects.load(name);
  if (!data) return;
  State.blocks          = data.blocks         || [];
  State.globalStyles    = data.globalStyles   || State.globalStyles;
  State.currentTemplate = data.currentTemplate || 'glass';
  State.customCSS       = data.customCSS      || '';
  State.blockIdCounter  = data.blockIdCounter || 1;
  applyTemplate(State.currentTemplate);
  refreshPreview();
  updateLayers();
  showToast('📂 Loaded', '"' + name + '" loaded', 'success');
}

function deleteProject(name) {
  SSConfirm.show('Delete "' + name + '"?', 'This cannot be undone.', () => {
    _deleteProjectInternal(name);
  });
}

function _deleteProjectInternal(name) {
  Projects.delete(name);
  showToast('🗑 Deleted', '"' + name + '" deleted', 'info');
  renderProjectsList();
}

function renderProjectsList() {
  const list = document.getElementById('projects-list');
  if (!list) return;
  const all = Projects.list();
  const keys = Object.keys(all);
  if (!keys.length) {
    list.innerHTML = '<div style="opacity:0.5;font-size:13px;padding:12px 0;">No saved projects yet.</div>';
    return;
  }
  list.innerHTML = keys.map(name => `
    <div class="project-item">
      <span class="project-name" onclick="loadProject('${name}')">${name}</span>
      <button class="project-delete" onclick="deleteProject('${name}')">🗑</button>
    </div>`).join('');
}
