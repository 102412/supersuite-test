/* ═══════════════════════════════════════════════════════════════════
   SUPERSUITE — ss-state.js
   SSV26.1 · Single source of truth for all app state.
   ─────────────────────────────────────────────────────────────────
   BACKEND UPGRADE (when ready):
     No changes needed in this file.
     Add State.accessCode = '' here if you want to initialise it.
═══════════════════════════════════════════════════════════════════ */

'use strict';

const State = {
  authenticated:      false,
  userTier:           'free',       // set by Auth.verify() on login
  accessCode:         '',           // set by checkPassword() — used by ss-export.js burn flow

  currentTemplate:    'glass',
  currentDevice:      'desktop',
  zoomLevel:          100,

  blocks:             [],           // array of block objects
  selectedBlockId:    null,
  selectedElement:    null,

  globalStyles: {
    '--primary':       '#ff6b35',
    '--secondary':     '#1a1a2e',
    '--accent':        '#ffd700',
    '--bg':            '#ffffff',
    '--text':          '#1a1a2e',
    '--font-heading':  "'Syne', sans-serif",
    '--font-body':     "'DM Sans', sans-serif",
    '--font-base':     '16px',
    '--line-height':   '1.6',
    '--btn-radius':    '8px',
    '--section-pad':   '60px',
    '--container':     '1200px',
    '--radius':        '12px',
    '--shadow':        '0 8px 24px rgba(0,0,0,0.15)',
  },

  customCSS:          '',
  uploadedImages:     {},           // key → base64

  scrollAnimation:    'off',        // off | subtle | soft | dramatic
  onboardingComplete: false,
  industry:           '',
  businessName:       '',
  blockIdCounter:     1,
};
